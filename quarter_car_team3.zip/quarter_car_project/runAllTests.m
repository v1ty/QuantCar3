%% runAllTests.m
% Run all four road cases, score each case, save a table, and make one figure.

quarterCarParameters

modelName = 'quarter_car_model';
load_system(modelName)
set_param(modelName, 'StopTime', num2str(stopTime))

numberOfCases = numel(roads.caseNames);
resultRows = cell(numberOfCases, 1);

for i = 1:numberOfCases
    roadName = roads.caseNames{i};
    roadInput = roads.(roadName);

    fprintf('\nRunning %s...\n', roadName);

    simOut = sim(modelName, 'StopTime', num2str(stopTime),'ReturnWorkspaceOutputs', 'on');

    resultRows{i} = scoreSuspension(simOut, roadName, flatRoadBodyH, flatRoadTireH, limits);
end

summaryTable = struct2table(vertcat(resultRows{:}));

disp(summaryTable)

% Save the numerical results.
writetable(summaryTable, 'quarterCarSummary.csv')

figure
bar(categorical(summaryTable.Road), summaryTable.Score)
ylabel('Score')
title('Quarter-Car Road Test')
grid on
saveas(gcf, 'quarterCarSummary.png')

