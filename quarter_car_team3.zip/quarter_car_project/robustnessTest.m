%% robustnessTest.m
% Task 6: Increase sprung mass by 25 percent and rerun all road cases.

quarterCarParameters
selectedKs
% Use the selected suspension design.
ks = selectedKs;
cs = selectedCs;

% Apply the required +25 percent payload variation.
ms = 1.25 * ms;

% Recalculate static equilibrium for the heavier vehicle corner.
suspStaticCompression = (ms * g) / ks;
tireStaticCompression = ((ms + mu) * g) / kt;

suspJointPosition0 = Ls - suspStaticCompression;
tireJointPosition0 = Lt - tireStaticCompression;

flatRoadTireH = tireJointPosition0;
flatRoadBodyH = tireJointPosition0 + suspJointPosition0;

modelName = 'quarter_car_model';
load_system(modelName)
set_param(modelName, 'StopTime', num2str(stopTime))

resultRows = cell(numel(roads.caseNames), 1);

for i = 1:numel(roads.caseNames)
    roadName = roads.caseNames{i};
    roadInput = roads.(roadName);

    simOut = sim(modelName, ...
        'StopTime', num2str(stopTime), ...
        'ReturnWorkspaceOutputs', 'on');

    resultRows{i} = scoreSuspension( ...
        simOut, roadName, flatRoadBodyH, flatRoadTireH, limits);
end

robustnessTable = struct2table(vertcat(resultRows{:}));
disp(robustnessTable)

% Required robustness summary.
worstRmsBodyAccel = max(robustnessTable.RMSBodyAccel);
worstSuspensionTravel = max(robustnessTable.MaxSuspensionTravel_mm);
worstTireDeflection = max(robustnessTable.MaxTireDeflection_mm);
passRate = 100 * mean(robustnessTable.PassAll);

fprintf('\nRobustness summary with +25%% sprung mass:\n');
fprintf('Worst RMS body acceleration: %.3f m/s^2\n', worstRmsBodyAccel);
fprintf('Worst suspension travel: %.1f mm\n', worstSuspensionTravel);
fprintf('Worst tire deflection: %.1f mm\n', worstTireDeflection);
fprintf('Pass rate: %.1f %%\n', passRate);

writetable(robustnessTable, 'robustnessResults.csv')
