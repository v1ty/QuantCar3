function roads = roadSuite(stopTime, dt) %stop time is how long it lasts, and dt represens each time sample

t = (0:dt:stopTime).'; %time vector
% case 1. Speed bump
speedBump = makeSmoothPulse(t, 1.0, 0.80, 0.050); %uses this function that simulates a 50 mm bump that lasts 0.8 seconds

% case 2. Pothole
pothole = makeSmoothPulse(t, 1.0, 0.75, -0.040);% last 0.75 seconds and dips down 40 mm
% case 3. Rough road
rng(15); % finds a random seed and makes noise
rawNoise = randn(size(t));
roughRoad = movmean(rawNoise, 20) - movmean(rawNoise, 500); %takes the mean of the noise to not have any farfetched dips
roughRoad = roughRoad - mean(roughRoad);
fade = min(max((t - 0.5) / 0.5, 0), 1);
roughRoad = roughRoad .* fade;
steadyPart = t >= 1.0;
roughRms = sqrt(mean(roughRoad(steadyPart).^2));
if roughRms > 0
    roughRoad = roughRoad * (0.004 / roughRms);
end
% case 4. Two bumps, two same sized bumps that happen 3 seconds apart
% from each other
twoBumps =  makeSmoothPulse(t, 1.0, 0.65, 0.040) + makeSmoothPulse(t, 4.0, 0.65, 0.040);

roads.time = t;
roads.units = 'm';
roads.speedBump = timeseries(speedBump, t, 'Name', 'Speed bump');
roads.pothole   = timeseries(pothole,   t, 'Name', 'Pothole');
roads.roughRoad = timeseries(roughRoad, t, 'Name', 'Rough road');
roads.twoBumps  = timeseries(twoBumps,  t, 'Name', 'Two bumps');
roads.caseNames = { 'speedBump',   'pothole',   'roughRoad',  'twoBumps'};
end
function z = makeSmoothPulse(t, startTime, duration, height)

z = zeros(size(t));
mask = t >= startTime & t <= startTime + duration;
x = (t(mask) - startTime) / duration;
z(mask) = height * sin(pi * x); %makes bump and pothole
end