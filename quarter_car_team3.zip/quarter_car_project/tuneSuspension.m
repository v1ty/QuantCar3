function [tuningTable, bestDesign] = tuneSuspension
%after running this function do , type selectedKs = bestDesign.Ks; ...
% selectedCs = bestDesign.Cs; in command window 
quarterCarParameters

ksValues = [12000 16000 20000];
csValues = [700 1000 1300];

roadNames = roads.caseNames;

Ks = [];
Cs = [];
AverageScore = [];
PassAll = [];

row = 1;

for i = 1:length(ksValues)

    for j = 1:length(csValues)

        testKs = ksValues(i);
        testCs = csValues(j);

        totalScore = 0;
        allPassed = true;

        flatRoadTireH = Lt -((ms + mu) * g) / kt;

        flatRoadBodyH = flatRoadTireH + ...
            (Ls - (ms * g) / testKs);

        for r = 1:length(roadNames)

            roadName = roadNames{r};
            roadInput = roads.(roadName);

            simIn = Simulink.SimulationInput('quarter_car_model');

            simIn = simIn.setVariable('ks', testKs);

            simIn = simIn.setVariable('cs', testCs);

            simIn = simIn.setVariable('roadInput', roadInput);

            simIn = simIn.setVariable( 'flatRoadyBodyH', flatRoadBodyH);

            simIn = simIn.setVariable( 'flatRoadTireH', flatRoadTireH);

            simIn = simIn.setModelParameter( 'StopTime', num2str(stopTime));

            simOut = sim(simIn);

            result = scoreSuspension( simOut,  roadName,  flatRoadBodyH, flatRoadTireH,  limits);

            totalScore = totalScore + result.Score;

            if result.PassAll == false
                allPassed = false;
            end

        end

        Ks(row,1) = testKs;
        Cs(row,1) = testCs;

        AverageScore(row,1) = totalScore / length(roadNames);

        PassAll(row,1) = allPassed;

        row = row + 1;

    end

end

tuningTable = table(  Ks, Cs, AverageScore, PassAll);

disp(tuningTable)

passing = tuningTable(tuningTable.PassAll == true, :);

if isempty(passing)

    [~, bestRow] =  min(tuningTable.AverageScore);

    bestDesign =  tuningTable(bestRow,:);

else

    [~, bestRow] =  min(passing.AverageScore);

    bestDesign =   passing(bestRow,:);

end

disp('Best design:')
disp(bestDesign)

end