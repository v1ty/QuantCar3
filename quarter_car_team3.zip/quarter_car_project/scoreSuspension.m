function result = scoreSuspension(simOut, roadName,flatRoadBodyH, flatRoadTireH, limits)

% Get simulation outputs
as = simOut.get('as'); %sprung accel
zs = simOut.get('zs'); % sprung pos
zu = simOut.get('zu'); %unsprung pos
zr = simOut.get('zr'); %road pos
as = as.Data;
zs = zs.Data;
zu = zu.Data;
zr = zr.Data;

% Suspension travel
suspensionTravel = (zs - zu) - (flatRoadBodyH - flatRoadTireH);

% Tire deflection
tireDeflection = (zu - zr) - flatRoadTireH;

% Calculate metrics
rmsBodyAccel = sqrt(mean(as.^2));

maxSuspensionTravel =  max(abs(suspensionTravel));

maxTireDeflection = max(abs(tireDeflection));

% Check requirements
passComfort = rmsBodyAccel <= limits.maxRmsBodyAccel;

passTravel =maxSuspensionTravel <= limits.maxSuspensionTravel;

passRoadHolding = maxTireDeflection <= limits.maxTireDeflection;

passAll = passComfort && passTravel && passRoadHolding;

% Overall score
score = rmsBodyAccel / limits.maxRmsBodyAccel +maxSuspensionTravel / limits.maxSuspensionTravel +  maxTireDeflection / limits.maxTireDeflection;

% outputs
result.Road = string(roadName);

result.RMSBodyAccel = rmsBodyAccel;

result.MaxSuspensionTravel = 1000 * maxSuspensionTravel;

result.MaxTireDeflection = 1000 * maxTireDeflection;

result.Score = score;

result.PassComfort = passComfort;
result.PassTravel = passTravel;
result.PassRoadHolding = passRoadHolding;
result.PassAll = passAll;

end